<?php 
    ini_set("display_errors", "On");
    error_reporting(E_ALL);
    session_start();

    require_once __DIR__ . "../../../constants.php";
    require __DIR__ . '../../../database/db_connect.php';

    $cart_products = json_decode(file_get_contents("php://input"), true);

    // $cart_products = json_decode($cart_products, true);

    // echo var_dump($cart_products);


    if(!isset($_SESSION["login_user_id"])){
      header("Location: ../login.php");
      exit();
    } else {  
      $login_user_id = $_SESSION["login_user_id"];
    }

    // getting current user details 
    $current_user_sql = "SELECT * FROM users WHERE user_id = $login_user_id";
    $current_user_stmt = $conn->prepare($current_user_sql);
    $current_user_stmt->execute();
    $user = $current_user_stmt->fetchAll(PDO::FETCH_ASSOC);


?>






<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="description" content="" />
  <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors" />
  <meta name="generator" content="Astro v5.13.2" />
  <title>Checkout example · Bootstrap v5.3</title>
  <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/checkout/" />
  <!-- <script src="../assets/js/color-modes.js"></script> -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

  <!-- <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet" /> -->
  <meta name="theme-color" content="#712cf9" />
  <link href="checkout.css" rel="stylesheet" />
  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }

    .b-example-divider {
      width: 100%;
      height: 3rem;
      background-color: #0000001a;
      border: solid rgba(0, 0, 0, 0.15);
      border-width: 1px 0;
      box-shadow: inset 0 0.5em 1.5em #0000001a,
        inset 0 0.125em 0.5em #00000026;
    }

    .b-example-vr {
      flex-shrink: 0;
      width: 1.5rem;
      height: 100vh;
    }

    .bi {
      vertical-align: -0.125em;
      fill: currentColor;
    }

    .nav-scroller {
      position: relative;
      z-index: 2;
      height: 2.75rem;
      overflow-y: hidden;
    }

    .nav-scroller .nav {
      display: flex;
      flex-wrap: nowrap;
      padding-bottom: 1rem;
      margin-top: -1px;
      overflow-x: auto;
      text-align: center;
      white-space: nowrap;
      -webkit-overflow-scrolling: touch;
    }

    .btn-bd-primary {
      --bd-violet-bg: #712cf9;
      --bd-violet-rgb: 112.520718, 44.062154, 249.437846;
      --bs-btn-font-weight: 600;
      --bs-btn-color: var(--bs-white);
      --bs-btn-bg: var(--bd-violet-bg);
      --bs-btn-border-color: var(--bd-violet-bg);
      --bs-btn-hover-color: var(--bs-white);
      --bs-btn-hover-bg: #6528e0;
      --bs-btn-hover-border-color: #6528e0;
      --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
      --bs-btn-active-color: var(--bs-btn-hover-color);
      --bs-btn-active-bg: #5a23c8;
      --bs-btn-active-border-color: #5a23c8;
    }

    .bd-mode-toggle {
      z-index: 1500;
    }

    .bd-mode-toggle .bi {
      width: 1em;
      height: 1em;
    }

    .bd-mode-toggle .dropdown-menu .active .bi {
      display: block !important;
    }
  </style>
</head>

<body class="bg-body-tertiary" onload="getData(event)">
  <div class="container">
    <main>
      <div class="py-5 text-center">
        <h1 class="h2">Checkout form</h1>

      </div>
      <div class="row g-5">
        <div class="col-md-5 col-lg-4 order-md-last" id="product_data">
          <!-- <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-primary">Your cart</span>
            <span class="badge bg-primary rounded-pill">3</span>
          </h4>
          <ul class="list-group mb-3">
            <li class="list-group-item d-flex justify-content-between lh-sm">
              <div>
                <h6 class="my-0">Product name</h6>
                <small class="text-body-secondary">Brief description</small>
              </div>
              <span class="text-body-secondary">$12</span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
              <span>Total (USD)</span> <strong>$20</strong>
            </li>
          </ul> -->
          <!-- <form class="card p-2">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Promo code" />
              <button type="submit" class="btn btn-secondary">Redeem</button>
            </div>
          </form> -->
        </div>
        <div class="col-md-7 col-lg-8">
          <h4 class="mb-3">Billing address</h4>
          <form class="needs-validation" id="checkout_form" method="post" action="./process_checkout.php" novalidate>
              <input type="hidden" name="amount" value="" id="cart_total">
              <input type="hidden" name="productinfo" value="" id="productinfo">
            <div class="row g-3">
              <?php foreach($user as $u) {?>
              <div class="col-sm-6">
                <label for="firstName" class="form-label">First name</label>
                <input type="text" class="form-control" id="firstName" name="firstname" placeholder="" value="<?php echo $u["first_name"] ?>" required />
                <div class="invalid-feedback">
                  Valid first name is required.
                </div>
              </div>
              <div class="col-sm-6">
                <label for="lastName" class="form-label">Last name</label>
                <input type="text" class="form-control" id="lastName" name="lastname" placeholder="" value="<?php echo $u["last_name"] ?>" required />
                <div class="invalid-feedback">
                  Valid last name is required.
                </div>
              </div>
              <div class="col-12">
                <label for="phone_no" class="form-label">Phone no</label>
                <input type="text" class="form-control" id="phone_no" name="phone" placeholder="phone no" value="<?php echo $u["phone_no"] ?>" />
                <div class="invalid-feedback">
                </div>
              </div>
              <div class="col-12">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="you@example.com" value="<?php echo $u["email"] ?>"/>
                <div class="invalid-feedback">
                  Please enter a valid email address for shipping updates.
                </div>
                <?php } ?>
              </div>
              <div class="col-12">
                <label for="address" class="form-label">Address</label>
                <input type="text" class="form-control" id="address1" name="address1" placeholder="1234 Main St" value="address 1" required />
                <div class="invalid-feedback">
                  Please enter your shipping address.
                </div>
              </div>
              <div class="col-md-3">
                <label for="country" class="form-label">Country</label>
                <select class="form-select" id="country" name="country" required>
                  <option value="">Choose...</option>
                  <option value="India" selected>India</option>
                </select>
                <div class="invalid-feedback">
                  Please select a valid country.
                </div>
              </div>
              <div class="col-md-3">
                <label for="state" class="form-label">State</label>
                <select class="form-select" id="state" name="state" required>
                  <option value="">Choose...</option>
                  <option value="Gujarat" selected>Gujarat</option>
                </select>
                <div class="invalid-feedback">
                  Please provide a valid state.
                </div>
              </div>
              <div class="col-md-3">
                <label for="city" class="form-label">City</label>
                <input type="text" class="form-control" id="city" name="city" value="abc" placeholder="" required />
                <div class="invalid-feedback">City required</div>
              </div>
              <div class="col-md-3">
                <label for="zip" class="form-label">Zip</label>
                <input type="text" class="form-control" id="zip" name="zipcode" placeholder="" value="123456" required />
                <div class="invalid-feedback">Zip code required.</div>
              </div>
            </div>
            <!-- <hr class="my-4" /> -->
            <!-- <div class="form-check">
              <input type="checkbox" class="form-check-input" id="same-address" />
              <label class="form-check-label" for="same-address">Shipping address is the same as my billing
                address</label>
            </div>
            <div class="form-check">
              <input type="checkbox" class="form-check-input" id="save-info" />
              <label class="form-check-label" for="save-info">Save this information for next time</label>
            </div> -->
            <hr class="my-4" />
            <h4 class="mb-3">Payment</h4>
            <div class="my-3">
              <div class="form-check">
                <input id="online" name="paymentMethod" type="radio" class="form-check-input" checked value="online" required />
                <label class="form-check-label" for="online">Online</label>
              </div>
              <div class="form-check">
                <input id="cod" name="paymentMethod" type="radio" class="form-check-input" value="cod" required />
                <label class="form-check-label" for="cod">Cash on delivery</label>
              </div>
            </div>


            <!-- <div class="row gy-3">
              <div class="col-md-6">
                <label for="cc-name" class="form-label">Name on card</label>
                <input type="text" class="form-control" id="cc-name" placeholder="" required />
                <small class="text-body-secondary">Full name as displayed on card</small>
                <div class="invalid-feedback">Name on card is required</div>
              </div>
              <div class="col-md-6">
                <label for="cc-number" class="form-label">Credit card number</label>
                <input type="text" class="form-control" id="cc-number" placeholder="" required />
                <div class="invalid-feedback">
                  Credit card number is required
                </div>
              </div>
              <div class="col-md-3">
                <label for="cc-expiration" class="form-label">Expiration</label>
                <input type="text" class="form-control" id="cc-expiration" placeholder="" required />
                <div class="invalid-feedback">Expiration date required</div>
              </div>
              <div class="col-md-3">
                <label for="cc-cvv" class="form-label">CVV</label>
                <input type="text" class="form-control" id="cc-cvv" placeholder="" required />
                <div class="invalid-feedback">Security code required</div>
              </div>
            </div> -->


            <hr class="my-4" />
            <button class="w-100 btn btn-primary btn-lg" type="submit">
              Continue to checkout
            </button>
          </form>
        </div>
      </div>
    </main>
    <footer class="my-5 pt-5 text-body-secondary text-center text-small">
      <p class="mb-1">&copy; 2017–2025 Company Name</p>
      <ul class="list-inline">
        <li class="list-inline-item"><a href="#">Privacy</a></li>
        <li class="list-inline-item"><a href="#">Terms</a></li>
        <li class="list-inline-item"><a href="#">Support</a></li>
      </ul>
    </footer>
  </div>
  <!-- <script
      src="../assets/dist/js/bootstrap.bundle.min.js"
      class="astro-vvvwv3sm"
    ></script> -->

    <script>

      let cart_total = 0.0;
      let products = [];
      let product_names = [];

      function getData(){
        const req = new XMLHttpRequest();
        req.open("GET", "./get_cart_data.php");
        req.send();
        req.addEventListener('load', function(){
          const res = JSON.parse(this.responseText);
          console.log(res.products);
          cart_total = res.cart_total;
          products = res.products;
          let data = `
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-primary">Your cart</span>
            <span class="badge bg-primary rounded-pill">${products.length}</span>
          </h4>
          <ul class="list-group mb-3">
          `; 

          products.forEach((product) => {
            product_names.push(product.product_name);
            data += `
            <li class="list-group-item d-flex justify-content-between lh-sm">
              <div>
                <h6 class="my-0">${product.product_name}</h6>
                <small class="text-body-secondary">quantity: ${product.quantity}</small>
              </div>
              <span class="text-body-secondary">${product.price}</span>
            </li>
            `;
          })

          data += `
          <li class="list-group-item d-flex justify-content-between">
              <span>Total (INR)</span> <strong>${res.cart_total}</strong>
            </li>
          </ul>
          `;

          document.getElementById("product_data").innerHTML = data;
          document.getElementById("cart_total").value = cart_total;
          document.getElementById("productinfo").value = product_names.join(' , ');

        })
      }


      // function sendData(event) {
      //     // const form = document.getElementById("checkout_form");
      //     event.preventDefault();
      //     const form = event.target;
      //     console.log(form);

      //     const formData = new FormData(form);
      //     formData.append("amount", cart_total);
      //     formData.append("productinfo", product_names.toString())

      //     const req = new XMLHttpRequest();
      //     req.open("POST", "./process_checkout.php");
      //     // req.open("POST", "./test.php");
      //     // req.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      //     // req.setRequestHeader('Content-Type', 'multipart/form-data');
      //     req.send(formData);
      //     // req.onload = function(){
      //     //   if()
      //     // }
      // }



    </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
    crossorigin="anonymous"></script>
  <script src="checkout.js" class="astro-vvvwv3sm"></script>
</body>

</html>