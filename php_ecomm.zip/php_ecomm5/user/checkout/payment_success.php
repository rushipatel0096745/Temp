<?php
ini_set("display_errors", "On");
error_reporting(E_ALL);

// session_set_cookie_params([
//     'lifetime' => 0,
//     'path' => '/',
//     'domain' => '', 
//     'secure' => true, 
//     'httponly' => true,
//     'samesite' => 'None' 
// ]);
session_start();
require __DIR__ . "/../../database/db_connect.php";
require "./PayU.php";
require "../../config/email_config.php";

use APITestCode\PayU;

$payu = new PayU();
$payu->salt = "ha18Zct9kuxwAa0n33blItch8fpdMs6l";
$payu->key  = $_POST['key'];

$status        = $_POST["status"];
$firstname     = $_POST["firstname"];
$amount        = $_POST["amount"];
$txnid         = $_POST["txnid"];
$posted_hash   = $_POST["hash"];
$key           = $_POST["key"];
$productinfo   = $_POST["productinfo"];
$email         = $_POST["email"];
$phone         = $_POST["phone"];
$address1      = $_POST["address1"];



$udf1 = $_POST['udf1'] ?? '';
$udf2 = $_POST['udf2'] ?? '';
$udf3 = $_POST['udf3'] ?? '';
$udf4 = $_POST['udf4'] ?? '';
$udf5 = $_POST['udf5'] ?? '';

// Response hash is in REVERSE order
$base = $payu->salt . '|' . $_POST['status'];

// Add additional charges if present
if (!empty($_POST['additionalCharges'])) {
    $base .= '|' . $_POST['additionalCharges'];
}

// Continue with reverse order
$base .= '||||||' . $udf5 . '|' . $udf4 . '|' . $udf3 . '|' . $udf2 . '|' . $udf1 . '|' .
    $_POST['email'] . '|' . $_POST['firstname'] . '|' . $_POST['productinfo'] . '|' .
    $_POST['amount'] . '|' . $_POST['txnid'] . '|' . $_POST['key'];

$calculatedHash = strtolower(hash('sha512', $base));

if ($calculatedHash !== $_POST['hash']) {
    die("Invalid Transaction - Hash Mismatch");
}

// $order_id = $_SESSION['current_order_id'] ?? 0;
$stmt = $conn->prepare("SELECT order_id, user_id FROM orders WHERE payment_txn_id = ?");
$stmt->execute([$txnid]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die("Order not found");
}

$order_id = $order['order_id'];
$user_id  = $order['user_id'];


$sql = "UPDATE orders 
        SET payment_status = 'SUCCESS'
        WHERE order_id = ? AND payment_txn_id = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$order_id, $txnid]);

unset($_SESSION['cart']);

// fetching user id from orders
$user_sql = "SELECT user_id FROM orders WHERE order_id = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->execute([$order_id]);
$user_id = $user_stmt->fetchColumn();

$_SESSION["login_user_id"] = $user_id;

$mailBody = "
    <div style='margin: auto;'> 
    <p>Order ID: $order_id </p>
    <p>Product information: $productinfo </p>
    <p>Transaction ID: $txnid </p>
    <p>Amount Paid: ₹$amount </p>
    </div>
";

$mail = initializeMailer();


if ($mail) {
    try {
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'New Order';
        $mail->Body = $mailBody;
        $mail->AltBody = $mailBody;
        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
} else {
    echo "Email config error";
}




// invoice
// $details = [
//             "amount" => $amount, "txnid" => $txnid, "productinfo" => $productinfo, "firstname" => $firstname, "email" => $email,
//              "phone" => $phone, "address1" => $address1, "city" => "test", "state" => "test", "country" => "test", "zipcode" => "122002", 
//              "validation_period" => "6", "send_email_now" => "1", "send_sms" => "1"
//             ];
// $param['details'] = json_encode($details);
// $invoice = $payu->createPaymentInvoice($param);
// print_r($invoice);


?>
<!DOCTYPE html>
<html>

<head>
    <title>Payment Success</title>
</head>

<body>
    <h2>Payment Successful</h2>
    <p>Order ID: <?= htmlspecialchars($order_id) ?></p>
    <p>Transaction ID: <?= htmlspecialchars($txnid) ?></p>
    <p>Amount Paid: ₹<?= htmlspecialchars($amount) ?></p>
    <a href="../orders.php">View My Orders</a>
</body>

</html>



<!-- // Save session before rendering
    // session_write_close(); -->