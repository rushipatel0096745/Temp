<?php

ini_set('display_errors', 'On');
error_reporting(E_ALL);
session_start();

require '../../database/db_connect.php';


// $login_user_id = $_SESSION["login_user_id"] ?? 0;
// fetch cart items
// $cart_items = $_SESSION["cart"] ?? [];

if (isset($_SESSION["login_user_id"])) {
    // return database cart data

    $user_id = $_SESSION["login_user_id"];

    $sql = "SELECT P.p_id, P.product_name, P.image, P.price, CI.quantity
                FROM cart C
                JOIN cart_items CI ON C.cart_id = CI.cart_id
                JOIN product P ON P.p_id = CI.p_id
                WHERE C.user_id = ?
                ";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$user_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $_SESSION["cart"] = [];
    foreach ($items as $item) {
        $_SESSION["cart"][$item["p_id"]] = $item["quantity"];
    }
} else {
    $cart_items = $_SESSION["cart"] ?? [];
    $items = [];

    if (!empty($cart_items)) {
        $all_product_ids = array_keys($cart_items);
        $placeholder = array_fill(0, count($all_product_ids), "?");
        $placeholder = implode(",", $placeholder);

        $product_sql = "SELECT p_id, product_name, price, image FROM product WHERE p_id IN ($placeholder)";
        $product_stmt = $conn->prepare($product_sql);
        $product_stmt->execute($all_product_ids);
        $products = $product_stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($products as &$product) {
            $items[] = [
                "p_id" => $product["p_id"],
                "product_name" => $product["product_name"],
                "image" => $product["image"],
                "price" => $product["price"],
                "quantity" => $cart_items[$product["p_id"]]
            ];
        }
    } else {
        $items = [];
        $cart_total = 0;
    }
}


// adding subtotal for each item
foreach ($items as &$item) {
    $item["subtotal"] = $item["price"] * $item["quantity"];
}

// unset the $item (remove the reference)
unset($item);

$cart_total = 0;
// for cart total
foreach ($items as $item) {
    $cart_total += $item["subtotal"];
}


echo json_encode(["cart_total" => $cart_total, "products" => $items]);