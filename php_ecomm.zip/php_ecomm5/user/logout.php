<?php

    session_start();
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);

    if(isset($_SESSION["login_user_id"])){
        unset($_SESSION["login_user_id"]);
        unset($_SESSION["cart"]);
        header("location: ./login.php");
        exit();
    }

?>