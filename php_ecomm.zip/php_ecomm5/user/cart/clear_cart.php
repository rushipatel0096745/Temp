<?php

session_start();

require_once __DIR__ . "../../../constants.php";
require __DIR__ . '../../../database/db_connect.php';

$_SESSION["cart"] = [];

if (isset($_SESSION["login_user_id"])) {
    $user_id = $_SESSION["login_user_id"];

    $stmt = $conn->prepare("SELECT cart_id FROM cart WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $cart_id = $stmt->fetchColumn();

    // remove products from the cart_items for logged in user
    if ($cart_id) {
        $remove_sql = "DELETE FROM cart_items WHERE cart_id = ?";
        $remove_stmt = $conn->prepare($remove_sql);
        $remove_stmt->execute([$cart_id]);
    }
}

echo "Cart cleared";