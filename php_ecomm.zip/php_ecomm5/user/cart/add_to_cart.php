<?php 

    session_start();
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);

    require_once __DIR__ . "../../../constants.php";
    require __DIR__ . '../../../database/db_connect.php';

    if(isset($_POST["product_id"])){
        $product_id = (int)$_POST["product_id"];
    }
    
    if(!isset($_SESSION["cart"])){
        $_SESSION["cart"] = [
            $product_id => 1
        ];
    } else {
        if(in_array($product_id, array_keys($_SESSION["cart"]))){
            // $_SESSION["cart"][$product_id] += 1;
            echo "product is already in the cart";
            exit();
        } else {
            $_SESSION["cart"] += [
                $product_id => 1
            ];
        }
    }

    // if user logged in then store in cart and cart items
    if(isset($_SESSION["login_user_id"])) {

        // checking user has existed cart in cart table
        $user_cart_sql = "SELECT cart_id FROM cart WHERE user_id = ?";
        $user_cart_stmt = $conn->prepare($user_cart_sql);
        $user_cart_stmt->execute([$_SESSION["login_user_id"]]);
        $cart_id = $user_cart_stmt->fetchColumn();
        $_SESSION["cart_id"] = $cart_id ?? 0;

        if(!$cart_id) {
            // insert into cart
            $insert_cart_sql = "INSERT INTO cart(user_id) VALUES (?)";
            $insert_cart_stmt = $conn->prepare($insert_cart_sql);
            $insert_cart_stmt->execute([$_SESSION["login_user_id"]]);
            $new_cart_id  = $conn->lastInsertId();
            $_SESSION["cart_id"] = $new_cart_id;

            // inssert into cart_items with new cart_id
            $insert_cart_item_sql = "INSERT INTO cart_items(cart_id, p_id, quantity) VALUES (?,?,?)";
            $insert_cart_items_stmt = $conn->prepare($insert_cart_item_sql);
            $insert_cart_items_stmt->execute([$new_cart_id, $product_id, $_SESSION["cart"][$product_id]]);
        } else {
            // inssert into cart_items with existed cart_id
            $insert_cart_item_sql = "INSERT INTO cart_items(cart_id, p_id, quantity) VALUES (?,?,?)";
            $insert_cart_items_stmt = $conn->prepare($insert_cart_item_sql);
            $insert_cart_items_stmt->execute([$cart_id, $product_id, $_SESSION["cart"][$product_id]]);
        }
    } 
    
    echo "product added to cart";        
    

?>