-- Adminer 4.8.1 MySQL 8.0.44-0ubuntu0.22.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DELIMITER ;;

DROP PROCEDURE IF EXISTS `getStudents`;;
CREATE PROCEDURE `getStudents`()
BEGIN 
    SELECT * FROM student;
END;;

DELIMITER ;

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password_hash` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `role_id` int DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_role_id` (`role_id`),
  CONSTRAINT `fk_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `admin` (`admin_id`, `name`, `email`, `password_hash`, `role_id`) VALUES
(1,	'admin',	'admin@gmail.com',	'$2y$10$rbNprytOIR2k7OPcVGn7LOLDy3d.FL3Tt2osfMcJUbtNvp9G.Bssu',	1),
(28,	'john11',	'john@gmail.com',	'$2y$10$EQNKQP/ym5.2SXITI5NMP.avEnd2dNZOSI1Bg5NN1AMHik.d3s4zy',	2),
(29,	'john',	'john22@gmail.com',	'$2y$10$Ela9HISa2pKBF9aQrW/Bu.4cdHZsMAt2LN9J/la9kyuK52uP5IK5a',	2),
(36,	'joe',	'rushikesh.corewix@gmail.com',	'$2y$10$uKeb5Cj4O8eNqs8UkBs7F.4NJSQrImoWxMsRpggoU3eZY9zol3zJ.',	4);

DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `cart_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cart_id`),
  KEY `PK_cart` (`user_id`),
  CONSTRAINT `PK_cart` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `cart` (`cart_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1,	13,	'2026-01-05 14:00:30',	'2026-01-05 14:00:30');

DROP TABLE IF EXISTS `cart_items`;
CREATE TABLE `cart_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cart_id` int NOT NULL,
  `p_id` int NOT NULL,
  `quantity` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `c_fk` (`p_id`),
  KEY `FK_cart` (`cart_id`),
  CONSTRAINT `c_fk` FOREIGN KEY (`p_id`) REFERENCES `product` (`p_id`),
  CONSTRAINT `FK_cart` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`cart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `cart_items` (`id`, `cart_id`, `p_id`, `quantity`, `created_at`, `updated_at`) VALUES
(7,	1,	36,	1,	'2026-01-05 16:02:35',	'2026-01-05 16:02:35');

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `c_id` int NOT NULL,
  `category_name` varchar(30) NOT NULL,
  PRIMARY KEY (`c_id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `category` (`c_id`, `category_name`) VALUES
(4,	'chair'),
(1,	'electronics'),
(3,	'furniture'),
(2,	'mobile'),
(5,	'table');

DROP TABLE IF EXISTS `navigation`;
CREATE TABLE `navigation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `url` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `parent_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_nav` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `navigation` (`id`, `name`, `url`, `parent_id`, `created_at`, `updated_at`) VALUES
(1,	'Home',	'http://localhost/rushikesh/php_ecomm/user/index.php',	0,	'2025-12-30 11:30:05',	'2025-12-30 11:30:05'),
(2,	'Cart',	'http://localhost/rushikesh/php_ecomm/user/cart.php',	0,	'2025-12-31 09:11:49',	'2025-12-31 09:11:49'),
(8,	'Orders',	'http://localhost/rushikesh/php_ecomm/user/orders.php',	0,	'2025-12-31 16:10:05',	'2025-12-31 16:10:05');

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `p_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `p_id` (`p_id`),
  KEY `ot_fk` (`order_id`),
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`p_id`) REFERENCES `product` (`p_id`),
  CONSTRAINT `ot_fk` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `order_items` (`id`, `order_id`, `p_id`, `quantity`, `unit_price`) VALUES
(124,	93,	36,	1,	325.25),
(125,	93,	42,	1,	350.25),
(126,	94,	36,	1,	325.25),
(127,	95,	42,	1,	350.25),
(128,	96,	36,	1,	325.25),
(129,	97,	42,	1,	350.25),
(130,	99,	36,	1,	325.25),
(131,	100,	36,	1,	325.25);

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `order_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order_total` decimal(10,2) NOT NULL,
  `payment_mode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `payment_txn_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `payment_status` enum('PENDING','SUCCESS') DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`),
  KEY `o_fk` (`user_id`),
  CONSTRAINT `o_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `orders` (`order_id`, `user_id`, `order_date`, `order_total`, `payment_mode`, `payment_txn_id`, `payment_status`, `created_at`, `updated_at`) VALUES
(93,	10,	'2026-01-05 09:25:16',	675.50,	'ONLINE',	'txn_695b3624cb2e7',	'PENDING',	'2026-01-05 09:25:16',	'2026-01-05 09:25:16'),
(94,	10,	'2026-01-05 09:26:58',	325.25,	'COD',	'txn_695b368a14528',	'SUCCESS',	'2026-01-05 09:26:58',	'2026-01-05 09:26:58'),
(95,	10,	'2026-01-05 09:40:01',	350.25,	'ONLINE',	'txn_695b399925cd2',	'PENDING',	'2026-01-05 09:40:01',	'2026-01-05 09:40:01'),
(96,	10,	'2026-01-05 09:58:42',	325.25,	'ONLINE',	'txn_695b3dfa1ded9',	'SUCCESS',	'2026-01-05 09:59:00',	'2026-01-05 09:58:42'),
(97,	13,	'2026-01-05 10:14:38',	350.25,	'ONLINE',	'txn_695b41b6efbb5',	'SUCCESS',	'2026-01-05 10:14:56',	'2026-01-05 10:14:38'),
(98,	13,	'2026-01-05 10:38:53',	0.00,	'ONLINE',	'txn_695b4765496c3',	'PENDING',	'2026-01-05 10:38:53',	'2026-01-05 10:38:53'),
(99,	13,	'2026-01-05 10:39:11',	325.25,	'ONLINE',	'txn_695b477762e53',	'SUCCESS',	'2026-01-05 10:39:27',	'2026-01-05 10:39:11'),
(100,	13,	'2026-01-05 10:44:25',	325.25,	'ONLINE',	'txn_695b48b15820b',	'SUCCESS',	'2026-01-05 10:44:43',	'2026-01-05 10:44:25');

DROP TABLE IF EXISTS `password_reset`;
CREATE TABLE `password_reset` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_id` int NOT NULL,
  `email` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `otp` varchar(10) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `admin_id` (`admin_id`),
  CONSTRAINT `password_reset_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `password_reset` (`id`, `admin_id`, `email`, `otp`, `expires_at`, `created_at`) VALUES
(1,	36,	'rushikesh.corewix@gmail.com',	'7298',	'2025-12-22 10:33:55',	'2025-12-22 10:18:55');

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `p_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(30) NOT NULL,
  `price` float NOT NULL,
  `compare_price` float DEFAULT NULL,
  `image` varchar(60) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `product` (`p_id`, `product_name`, `price`, `compare_price`, `image`, `description`, `created_at`, `updated_at`) VALUES
(36,	'Product 1',	325.25,	350.6,	'https://picsum.photos/id/250/50/',	'description 1',	'2025-12-23 04:42:25',	'2025-12-23 04:42:25'),
(42,	'Product 2',	350.25,	450.5,	'https://picsum.photos/id/250/50/',	'Description for product 2',	'2025-12-23 06:20:39',	'2025-12-23 06:20:39');

DROP TABLE IF EXISTS `product_category`;
CREATE TABLE `product_category` (
  `p_id` int NOT NULL,
  `c_id` int NOT NULL,
  PRIMARY KEY (`p_id`,`c_id`),
  KEY `c_id` (`c_id`),
  CONSTRAINT `product_category_ibfk_13` FOREIGN KEY (`c_id`) REFERENCES `category` (`c_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `product_category_ibfk_14` FOREIGN KEY (`p_id`) REFERENCES `product` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `product_category` (`p_id`, `c_id`) VALUES
(36,	1),
(36,	2),
(42,	3),
(42,	4);

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `role_id` int NOT NULL,
  `role_name` varchar(20) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `roles` (`role_id`, `role_name`) VALUES
(1,	'administrator'),
(2,	'staff'),
(3,	'accounts'),
(4,	'manager');

DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `tid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `subj1` int DEFAULT NULL,
  `subj2` int DEFAULT NULL,
  `subj3` int DEFAULT NULL,
  `total` int DEFAULT NULL,
  `percentage` int DEFAULT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `student` (`tid`, `name`, `subj1`, `subj2`, `subj3`, `total`, `percentage`) VALUES
(1,	'Ram',	58,	52,	55,	165,	99),
(2,	'Raju',	58,	55,	56,	169,	101);

DELIMITER ;;

CREATE TRIGGER `stud_marks` BEFORE INSERT ON `student` FOR EACH ROW
SET NEW.total = NEW.subj1 + NEW.subj2 + NEW.subj3,
    NEW.percentage = (NEW.subj1 + NEW.subj2 + NEW.subj3) * 60 / 100;;

CREATE TRIGGER `after_student_insert` AFTER INSERT ON `student` FOR EACH ROW
INSERT INTO students_log(student_id, action) VALUES (NEW.tid, "Inserted");;

DELIMITER ;

DROP TABLE IF EXISTS `students_log`;
CREATE TABLE `students_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `action_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `students_log` (`id`, `student_id`, `action_time`, `action`) VALUES
(1,	2,	'2025-12-16 08:16:59',	'Inserted');

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_no` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `user` (`user_id`, `username`, `email`, `phone_no`, `password`) VALUES
(1,	'joe11',	'joe@gmail.com',	'9825265156',	'123456'),
(3,	'john11',	'john@gmail.com',	'9825265156',	'123456'),
(5,	'sds',	'john@gmail.com',	'7856254312',	'123456'),
(6,	'sds',	'john@gmail.com',	'7856254312',	'123456'),
(7,	'sds',	'john@gmail.com',	'7856254312',	'123456'),
(8,	'sds',	'john@gmail.com',	'7856254312',	'123456'),
(9,	'dsds',	'john@gmail.com',	'7856254312',	'123456');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password_hash` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `phone_no`, `email`, `password_hash`, `created_at`, `updated_at`) VALUES
(9,	'ram',	'doe',	'9825265156',	'ram@gmail.com',	'$2y$10$GUU4koRij6FFTGjVYv8.7OX4za33Pr4tBDKjuFOZaBTD09hPI.ZrC',	'2025-12-24 11:19:40',	'2025-12-24 11:19:40'),
(10,	'joe',	'doe',	'9825265156',	'joe@gmail.com',	'$2y$10$7W8PDK9JKY60O7LfwjZ4VOSsyqSUWhLLRuOVrChMh5RhEVG4.trAe',	'2025-12-30 08:47:35',	'2025-12-30 08:47:35'),
(11,	'john',	'patel',	'9825265156',	'john@gmail.com',	'$2y$10$Lg3ZG8DY0Riy.icTwxBkfOuTM5q9MwOe7t0ykfo8/KGClmMoFo2s6',	'2025-12-31 16:35:09',	'2025-12-31 17:27:54'),
(13,	'Rushi',	'Patel',	'9852525262',	'rushikesh.corewix@gmail.com',	'$2y$10$7A6Yfm07xUe9pj3xMO7uI.Rc2NcLE6M4XdFJGagqxWnnZU8ZVF5Ti',	'2026-01-05 10:06:12',	'2026-01-05 10:06:12');

-- 2026-01-05 11:05:33