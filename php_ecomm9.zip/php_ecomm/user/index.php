<?php
session_start();
ini_set('display_errors', 'On');
error_reporting(E_ALL);

require_once __DIR__ . "/../constants.php";

if (!isset($_SESSION["login_user_id"])) {
    header("Location: ./login.php");
    exit();
}

?>


<?php

require '../database/db_connect.php';

$sql = "
        SELECT P.p_id AS p_id, P.product_name AS product_name, P.price AS price, P.compare_price AS compare_price, P.image AS image, P.description AS description, GROUP_CONCAT(C.category_name) AS 'categories'
        FROM product P 
        LEFT JOIN product_category PC ON P.p_id = PC.p_id 
        LEFT JOIN category C ON C.c_id = PC.c_id
        GROUP BY P.p_id
    ";

$stmt = $conn->prepare($sql);
$stmt->execute();
$all_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

$category_sql = "SELECT * FROM category";
$category_stmt = $conn->prepare($category_sql);
$category_stmt->execute();
$categories = $category_stmt->fetchAll(PDO::FETCH_ASSOC);


?>



<!doctype html>
<html lang="en" data-bs-theme="dark">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>

<body onload="display_products(event)">

    <div class="container-fluid m-0 p-0">
        <!-- navbar -->
        <!-- <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Navbar</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                        <a class="nav-link" href="#">Features</a>
                        <a class="nav-link" href="#">Pricing</a>
                        <a class="nav-link disabled" aria-disabled="true">Disabled</a>
                    </div>
                </div>
            </div>
        </nav> -->

        <?php require '../user/components/user_navbar.php'; ?>


        <!-- listing all products -->
        <div class="products container-fluid">
            <div class="row mt-3 mb-3">
                <div class="col col-md-6">
                    <h1>Products</h1>
                </div>
                <div class="col col-md-3">
                    <form class="d-flex" role="search">
                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" id="search" onkeyup="display_products(event)" />
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </div>
                <div class="col col-md-3">
                    <div class="dropdown">
                        <!-- <a class="btn btn-secondary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Choose category
                        </a>
                        <ul class="dropdown-menu">
                            <?php foreach ($categories as $category) { ?>
                                <li><a class="dropdown-item" href="" onclick="display_products(event, 'category')"><?php echo $category["category_name"] ?></a></li>
                            <?php } ?>
                        </ul> -->

                        <button class="btn btn-success dropdown-toggle"
                            type="button"
                            id="multiSelectDropdown"
                            data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Select
                        </button>
                        <ul class="dropdown-menu"
                            aria-labelledby="multiSelectDropdown">
                            <?php foreach ($categories as $category) { ?>
                                <li>
                                    <label>
                                        <input type="checkbox"
                                            id="select_category"
                                            name="categories[]"
                                            value=<?php echo $category["c_id"] ?>
                                            onchange="display_products(event)">
                                        <?php echo $category["category_name"] ?>
                                    </label>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row row-cols-1 row-cols-md-4 g-3" id="product_data">
                <?php foreach ($all_products as $p) { ?>
                    <div class="col">
                        <div class="card h-100" style="width: 18rem;">
                            <img src="<?php echo $p["image"] ?>" class="card-img-top" alt="..." width="200px" height="200px">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $p["product_name"]; ?></h5>
                                <p class="card-text"><strong>Categories:</strong> <?php echo $p["categories"]; ?></p>
                                <p class="card-text"><strong>Description:</strong> <?php echo $p["description"]; ?></p>
                                <p class="card-text"><strong>Price: </strong><?php echo $p["price"]; ?>&#8377 <span class="text-decoration-line-through"><?php echo $p["compare_price"]; ?>&#8377 </span></p>
                                <a class="card-text" href="./product_details.php/?p_id=<?php echo $p['p_id']; ?>">View product</a>
                            </div>
                            <div class="card-footer">
                                <div class="col col-sm-6">
                                    <button onclick="addtoCart(event, <?php echo $p['p_id'] ?>)" class="btn btn-primary" target="">Add to Cart</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>

    </div>

    <script>
        const chBoxes =
            document.querySelectorAll('.dropdown-menu input[type="checkbox"]');
        const dpBtn =
            document.getElementById('multiSelectDropdown');
        let mySelectedListItems = [];

        function handleCB() {
            mySelectedListItems = [];
            let mySelectedListItemsText = '';

            chBoxes.forEach((checkbox) => {
                if (checkbox.checked) {
                    mySelectedListItems.push(checkbox.value);
                    // mySelectedListItemsText += checkbox.value + ', ';
                }
            });

            console.log(mySelectedListItems);

            // dpBtn.innerText =
            //     mySelectedListItems.length > 0 ?
            //     mySelectedListItemsText.slice(0, -2) : 'Select';
        }

        chBoxes.forEach((checkbox) => {
            checkbox.addEventListener('change', handleCB);
        });


        function addtoCart(event, product_id) {
            event.preventDefault();

            const req = new XMLHttpRequest();
            const formData = new FormData();

            formData.append("product_id", product_id);

            console.log(product_id);

            req.open("POST", "./cart/add_to_cart.php");
            req.send(formData);

            req.addEventListener('load', function() {
                // const res = JSON.parse(this.responseText);
                // alert("res");
                console.log(this.responseText);
                alert(this.responseText);
            })
        }

        function display_products(event, filterby = "") {

            const search = document.getElementById("search");

            let categories = [];
            let checkBoxes = document.querySelectorAll('.dropdown-menu input[type="checkbox"]')
            checkBoxes.forEach((checkBox) => {
                if (checkBox.checked) {
                    categories.push(checkBox.value)
                }
            })

            const formData = new FormData();
            formData.append("name", search.value);
            formData.append("categories", categories);

            const queryString = new URLSearchParams(formData).toString();
            // console.log(queryString);

            let url = 'http://localhost/rushikesh/php_ecomm/user/products/get_product_data.php/?' + queryString;
            console.log(url);

            const req = new XMLHttpRequest();

            req.open("GET", url);

            let data = "";
            req.addEventListener("load", function() {
                const result = JSON.parse(this.responseText);
                console.log(result.results);
                const products = result.results;

                products.forEach((product) => {
                    data += `
                        <div class="col">
                            <div class="card h-100" style="width: 18rem;">
                                <img src="${product["image"]}" class="card-img-top" alt="..." width="200px" height="200px">
                                <div class="card-body">
                                    <h5 class="card-title">${product["product_name"]}</h5>
                                    <p class="card-text"><strong>Categories:</strong> ${product.categories} </p>
                                    <p class="card-text"><strong>Description:</strong> ${product.description} </p>
                                    <p class="card-text"><strong>Price: </strong>${product["price"]}&#8377 <span class="text-decoration-line-through">${product["compare_price"]}&#8377 </span></p>
                                    <a class="card-text" href="./product_details.php/?p_id=${product["p_id"]}">View product</a>
                                </div>
                                <div class="card-footer">
                                    <div class="col col-sm-6">
                                        <button onclick="addtoCart(event, ${product["p_id"]})" class="btn btn-primary" target="">Add to Cart</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                })

                document.getElementById("product_data").innerHTML = data;


            });

            req.send();
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>

</html>