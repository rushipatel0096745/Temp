<?php
    session_start();
    if(!isset($_SESSION["login_user_id"])){
        header("Location: ../login.php");
        exit();
    }
?>

<?php 

    require '../../database/db_connect.php';

    $login_user_id = $_SESSION["login_user_id"];

    $errMsg = "";
    
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $current_pass = $_POST["currentPassword"];
        $new_pass = $_POST["newPassword"];
        $confirm_pass = $_POST["confirmPassword"];

        // echo "current pass". " " . $current_pass;
        // echo "new pass". " " . $new_pass;
        // echo "confirm pass". " " . $confirm_pass . "<br>";

    
        $sql = "SELECT password_hash FROM users WHERE user_id = :user_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":user_id", $login_user_id);
        $stmt->execute();
        $password_hash = $stmt->fetchColumn();

        // echo "old pass hash". " " . $password_hash . "<br>";

    
        $verify_pass = password_verify($current_pass, $password_hash);
        // echo "verify_pass". " " . $verify_pass . "<br>";


        if($verify_pass){
            if($new_pass == $confirm_pass){
                $new_pass_hash = password_hash($new_pass, PASSWORD_DEFAULT);
                // echo "new_pass_hash". " " . $new_pass_hash . "<br>";
                
                try{
                    $update_sql = "UPDATE users SET password_hash = :new_pass_hash WHERE user_id = $login_user_id";
                    $update_stmt = $conn->prepare($update_sql);
                    $update_stmt->bindParam(":new_pass_hash", $new_pass_hash);
                    // $update_stmt->bindParam(":admin_id", $login_user_id);
                    $update_stmt->execute();
                } catch(PDOException $e){
                    echo $sql . "<br>" . $e->getMessage();
                }
                $_SESSION["success"] = "password updated succesully";
                header("Location: profile.php");
                exit();
            }
        } else {
            $errMsg = "Current Password is incorrect";
        }
    }



?>

<!doctype html>
<html lang="en" data-bs-theme="dark">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Password Reset</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <style>
    *{
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }
  </style>
  <body>
    <div class="container d-flex align-items-center justify-content-center vh-100"> 
            <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
                <div class="row mb-3 text-center">
                    <h1>Reset Password</h1>
                </div>
                <div class="row mb-3">
                    <label for="password" class="col-sm-4 col-form-label">Current Password</label>
                    <div class="col-sm-8">
                    <input type="password" name="currentPassword" class="form-control" id="">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="newpassword" class="col-sm-4 col-form-label">New Password</label>
                    <div class="col-sm-8">
                    <input type="password" name="newPassword" class="form-control" id="">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="confirmpassword" class="col-sm-4 col-form-label">Confirm Password</label>
                    <div class="col-sm-8">
                    <input type="password" name="confirmPassword" class="form-control" id="">
                    </div>
                </div>
               

             
                <div class="row mb-3 justify-content-center text-center" style="margin-top: 30px;">
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
                <div class="row mb-3 justify-content-center text-center" style="margin-top: 30px;">
                    <div class="col-auto">
                       <p class="text-danger"><?php echo "$errMsg"; ?></p>
                    </div>
                </div>
        </form>

    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>