<?php 
    session_start();

    if (!isset($_SESSION["login_user_id"])) {
        header("Location: ../login.php");
        exit();
    } else {
        $user_id = $_SESSION["login_user_id"];
    }
    
    require '../../database/db_connect.php';

    $first_name = $_POST["first_name"];
    $last_name = $_POST["last_name"];
    $email = $_POST["email"];
    $phone_no = $_POST["phone_no"];

    $sql = "UPDATE users SET first_name = ?, last_name = ?, email = ?, phone_no = ? WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$first_name, $last_name, $email, $phone_no, intval($user_id)]);

    header("Location: ./profile.php");
    exit();



?>