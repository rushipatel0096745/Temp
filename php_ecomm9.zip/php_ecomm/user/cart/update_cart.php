<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL);
session_start();

require_once __DIR__ . "../../../constants.php";
require __DIR__ . '../../../database/db_connect.php';


$product_id = intval($_POST["product_id"]);
$action = $_POST["action"];

if (!isset($_SESSION["cart"])) {
    $_SESSION["cart"] = [];
}

if ($action == "increase") {
    $_SESSION["cart"][$product_id] = ($_SESSION["cart"][$product_id] ?? 0) + 1;
}
if ($action == "decrease") {
    if (!isset($_SESSION["cart"][$product_id])) {
        $_SESSION["cart"][$product_id] = 0;
    }

    $_SESSION["cart"][$product_id]--;

    if ($_SESSION["cart"][$product_id] <= 0) {
        unset($_SESSION["cart"][$product_id]);
    }
}


// for logged in user, update the database cart data
if (isset($_SESSION["login_user_id"])) {

    $user_id = $_SESSION["login_user_id"];

    // checking user has existed cart in cart table
    $user_cart_sql = "SELECT cart_id FROM cart WHERE user_id = ?";
    $user_cart_stmt = $conn->prepare($user_cart_sql);
    $user_cart_stmt->execute([$_SESSION["login_user_id"]]);
    $cart_id = $user_cart_stmt->fetchColumn();
    // $_SESSION["cart_id"] = $cart_id ?? 0;
    // echo "cart_id" . $cart_id;


    // update the cart and cart_item table
    if (!$_SESSION["cart"][$product_id]) {
        // remove product from the cart_item
        $remove_sql = "DELETE FROM cart_items WHERE p_id = ? AND cart_id = ?";
        $remove_stmt = $conn->prepare($remove_sql);
        $remove_stmt->execute([$product_id, $cart_id]);
    } else {
        $update_cart_sql = "UPDATE cart_items SET quantity = ? WHERE p_id = ? AND cart_id = ?";
        $update_cart_stmt = $conn->prepare($update_cart_sql);
        $update_cart_stmt->execute([$_SESSION["cart"][$product_id], $product_id, $cart_id]);
    }
}

echo json_encode(["quantity" => $_SESSION["cart"][$product_id] ?? 0]);


// echo json_encode(["quantity" => $_SESSION["cart"][$product_id] ?? 0, "product_total" => $product_total ?? 0, "total" => $cart_total]);
