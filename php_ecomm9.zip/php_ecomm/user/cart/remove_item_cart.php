<?php
session_start();
ini_set('display_errors', 'On');
error_reporting(E_ALL);

require_once __DIR__ . "../../../constants.php";
require __DIR__ . '../../../database/db_connect.php';

$product_id = intval($_POST["product_id"] ?? 0);

if (isset($_SESSION["cart"][$product_id])) {
    unset($_SESSION["cart"][$product_id]);
}

if (isset($_SESSION["login_user_id"])) {
    $user_id = $_SESSION["login_user_id"];

    $stmt = $conn->prepare("SELECT cart_id FROM cart WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $cart_id = $stmt->fetchColumn();

    if ($cart_id) {
        $conn->prepare("DELETE FROM cart_items WHERE cart_id = ? AND p_id = ?")
             ->execute([$cart_id, $product_id]);
    }
}
