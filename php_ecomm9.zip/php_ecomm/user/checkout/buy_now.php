<?php 

    session_start();

    $product_id = intval($_POST["product_id"]) ?? 0;

    $_SESSION["buy_now"] = [$product_id => 1];

    echo isset($_SESSION["buy_now"]) ? true : false;

?>