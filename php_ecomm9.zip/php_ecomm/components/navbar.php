<?php 
    // require __DIR__ . '../constants.php';
?>


<nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <!-- <a class="navbar-brand" href="http://localhost/rushikesh/project1/dashboard.php">Navbar</a>
                  -->
                <a class="navbar-brand" href="<?= BASE_PATH ?>admin/dashboard.php">Navbar</a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <!-- <a class="nav-link active" aria-current="page" href="http://localhost/rushikesh/project1/dashboard.php">Home</a> -->
                            <a class="nav-link active" aria-current="page" href="<?= BASE_PATH ?>admin/dashboard.php">Home</a>

                        </li>
                        <li class="nav-item">
                            <!-- <a class="nav-link active" aria-current="page" href="http://localhost/rushikesh/project1/products/products.php">Products</a> -->
                            <a class="nav-link active" aria-current="page" href="<?= BASE_PATH ?>admin/products/all_products.php">Products</a>
                        </li>
                        <li class="nav-item">
                            <!-- <a class="nav-link active" aria-current="page" href="http://localhost/rushikesh/project1/products/add_category.php">Category</a> -->
                            <a class="nav-link active" aria-current="page" href="<?= BASE_PATH ?>admin/products/category/add_category.php">Category</a>
                        </li>
                    </ul>
                </div>
                <div>
                    <!-- <a href="http://localhost/rushikesh/project1/profile.php" class="btn btn-primary">
                        Profile
                    </a> -->
                    <!-- <a href="../admin/profile/profile.php" class="btn btn-primary">Profile</a> -->
                    <a href="<?= BASE_PATH ?>admin/profile/profile.php" class="btn btn-primary">Profile</a>

                    <!-- <a href="http://localhost/rushikesh/project1/logout.php" class="btn btn-primary">
                        Logout
                    </a> -->
                    <a href="<?= BASE_PATH ?>admin/logout.php" class="btn btn-primary">
                        Logout
                    </a>
                </div>
            </div>
</nav>
