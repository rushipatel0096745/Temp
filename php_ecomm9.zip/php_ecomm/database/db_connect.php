<?php
$servername = "localhost";
$username = "root";
$password = "Root@123";
$dbname = "tmpUser";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // $sql = "insert into admin (email, password_hash, role_id, name) values (?,?,?,?)";
  // $sql = "UPDATE admin SET password_hash = ? WHERE admin_id = 1";
  // $stmt= $conn->prepare($sql);
  // $stmt->execute([password_hash('admin@123', PASSWORD_DEFAULT)]);



  // echo "Connected successfully";
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}

?>